<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <a href="/">
                <img src="<?php echo e(asset('image/Banjarbaru.png')); ?>" alt="Logo" class="logo">
            </a>
            <p class="logo-text">SOHIB BANJARBARU</p>
        </div>
        <form action="<?php echo e(route('postlogin')); ?>" method="POST" class="form-container" id="loginForm">
            <?php echo csrf_field(); ?>
            <?php if(Session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session('error')); ?>

                </div>
            <?php endif; ?>
            <h2 class="form-title">Login</h2>
            <div class="form-group">
                <label for="email">NIK Atau Email:</label>
                <input type="text" id="email" name="email" placeholder="Masukkan NIK atau Email Anda">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Masukkan Password Anda">
            </div>
            <div class="form-group">
                <button type="submit" onclick="checkRoleAndSubmit()">Login</button>
            </div>
        </form>
    </div>

    <script>
        function checkRoleAndSubmit() {
            var emailInput = document.getElementById('email');
            var emailValue = emailInput.value;

            // Check if the input looks like an email
            if (emailValue.includes('@') && emailValue.includes('.')) {
                // If it looks like an email, assume it's for admin
                document.getElementById('loginForm').action = "<?php echo e(route('postlogin')); ?>";
            } else {
                // Otherwise, assume it's for masyarakat
                document.getElementById('loginForm').action = "<?php echo e(route('postlogin')); ?>";

            // Submit the form
            document.getElementById('loginForm').submit();
        }
    }
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\submission-app\resources\views/Login/Login-admin.blade.php ENDPATH**/ ?>