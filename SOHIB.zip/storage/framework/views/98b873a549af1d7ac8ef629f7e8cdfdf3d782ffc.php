

<?php $__env->startSection('title', 'Search Results'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Search Results</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Search Results</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Search Results
        </div>
        <div class="card-body">
            <?php if(empty($submissions)): ?>
                <p>Silahkan ketik di sini.</p>
            <?php elseif($submissions->isEmpty()): ?>
                <p>No results found.</p>
            <?php else: ?>
                <table id="datatablesSimple" class="table">
                    <thead>
                        <tr>
                            <th>NIK</th>
                            <th>Nama</th>
                            <th>No Telepon</th>
                            <th>Email</th>
                            <th>Ibadah</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="searchResults">
                        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($submission->nik); ?></td>
                                <td><?php echo e($submission->name); ?></td>
                                <td><?php echo e($submission->phone); ?></td>
                                <td><?php echo e($submission->email); ?></td>
                                <td><?php echo e($submission->ibadah); ?></td>
                                <td><?php echo e($submission->status ?? 'NULL'); ?></td>
                                <td><a href="#">show</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masyarakat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\submission-app\resources\views/submissions/search-results.blade.php ENDPATH**/ ?>