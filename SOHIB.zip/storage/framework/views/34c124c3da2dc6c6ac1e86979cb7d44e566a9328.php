<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/login.css')); ?>">
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <img src="<?php echo e(asset('image/Banjarbaru.png')); ?>" alt="Logo" class="logo">
            <p class="logo-text">SOHIB BANJARBARU</p>
        </div>
        <form action="('/daftar')" method="POST" class="form-container">
            <?php echo csrf_field(); ?>
            <?php if(Session('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(Session('error')); ?>

                </div>
            <?php endif; ?>
            <h2 class="form-title">Daftar Akun</h2>
            <div class="form-group">
                <label for="nik">NIK:</label>
                <input type="text" id="nik" name="nik" placeholder="Masukkan NIK Anda">
            </div>
            <div class="form-group">
                <label for="name">Nama Lengkap:</label>
                <input type="text" id="name" name="name" placeholder="Masukkan Nama Lengkap Anda">
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Masukkan Email Anda">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Masukkan Password Anda">
            </div>
            <div class="form-group">
                <button type="submit">Register</button>
            </div>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\submission-app\resources\views/login/daftar.blade.php ENDPATH**/ ?>