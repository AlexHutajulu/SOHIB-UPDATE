

<?php $__env->startSection('title', 'SOHIB | Sistem Online Hibah Banjarbaru'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <?php if(auth()->check() && auth()->user()->role === 'masyarakat'): ?>
    <li class="breadcrumb-item active"><?php echo e(auth()->user()->name); ?></li>
<?php endif; ?>
    </ol>
    <div class="row">
        <!-- Bagian card Anda -->
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data Pengajuan Anda
        </div>
        <div class="card-body">
            <table id="datatablesSimple" class="table">
                <thead>
                    <tr>
                        <th>NIK</th>
                        <th>Nama Lengkap</th>
                        <th>Alamat</th>
                        <th>Ibadah</th>
                        <th>No Telepon</th>
                        <th>Email</th>
                        <th>Dokumen Anda</th>
                        <th>Status</th>
                        <th>Note</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($submission->nik); ?></td>
                            <td><?php echo e($submission->name); ?></td>
                            <td><?php echo e($submission->address); ?></td>
                            <td><?php echo e($submission->ibadah); ?></td>
                            <td><?php echo e($submission->phone); ?></td>
                            <td><?php echo e($submission->email); ?></td>
                            <td>
                                <a href="<?php echo e(route('submissions.file', ['id' => $submission->id])); ?>">
                                    <i class="fa-regular fa-eye fa-lg" style="color: #005eff; margin-right: 10px;"></i>
                                </a>                                
                            </td>
                            <td><?php echo e($submission->status); ?></td>
                            <td><?php echo e($submission->note); ?></td>
                            <td>
                                <!-- Actions di sini, contoh: -->
                                <a href="#" class="btn btn-primary">Ajukan Ulang</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masyarakat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\submission-app\resources\views/submissions/index.blade.php ENDPATH**/ ?>