

<?php $__env->startSection('title', 'Search Submissions'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Search Submissions</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Search Submissions</li>
    </ol>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-search me-1"></i>
            Search Submissions
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('search-submissions')); ?>" method="GET">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <input type="text" name="searchInput" class="form-control" placeholder="Search...">
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.masyarakat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\submission-app\resources\views/submissions/search.blade.php ENDPATH**/ ?>