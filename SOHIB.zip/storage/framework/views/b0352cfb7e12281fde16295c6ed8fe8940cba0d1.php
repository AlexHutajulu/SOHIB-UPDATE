

<?php $__env->startSection('title', 'Edit Submission'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4">Edit Submission</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('admin.new')); ?>">New Submissions</a></li>
        <li class="breadcrumb-item active">Edit Submission</li>
    </ol>

    <form action="<?php echo e(route('admin.update', $submission->id)); ?>" method="post" enctype="multipart/form-data" class="row g-2">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> 
        <!-- Formulir Anda -->
        <div class="col-md-6">
            <label for="nik" class="form-label">NIK :</label>
            <input type="text" class="form-control <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nik" id="nik"
                placeholder="Masukkan NIK Anda" value="<?php echo e(old('nik', $submission->nik)); ?>">
            <?php $__errorArgs = ['nik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="name" class="form-label">Nama :</label>
            <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="name" id="name"
                placeholder="Masukkan nama lengkap Anda" value="<?php echo e(old('name', $submission->name)); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="phone" class="form-label">Nomor Telepon :</label>
            <input type="text" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="phone" id="phone"
                placeholder="Masukkan nomor telepon Anda" value="<?php echo e(old('phone', $submission->phone)); ?>">
            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="email" class="form-label">Email :</label>
            <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email"
                placeholder="Masukkan nomor telepon Anda" value="<?php echo e(old('email', $submission->email)); ?>">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="ibadah" class="form-label">Nama tempat Ibadah :</label>
            <input type="text" class="form-control <?php $__errorArgs = ['ibadah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ibadah" id="ibadah"
                placeholder="Masukkan nama tempat Ibadah Secara Lengkap" value="<?php echo e(old('ibadah', $submission->ibadah)); ?>">
            <?php $__errorArgs = ['ibadah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="budget" class="form-label">Anggaran Biaya :</label>
            <input type="number" class="form-control <?php $__errorArgs = ['budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="budget" id="budget"
                placeholder="Masukkan nominal Rencana Anggaran Biaya" value="<?php echo e(old('budget', $submission->budget)); ?>">
            <?php $__errorArgs = ['budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="bank_account" class="form-label">Rekening BANK :</label>
            <input type="text" class="form-control <?php $__errorArgs = ['bank_account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="bank_account" id="bank_account"
                placeholder="Masukkan No rekening BANK atas Nama Tempat Ibadah" value="<?php echo e(old('bank_account', $submission->bank_account)); ?>">
            <?php $__errorArgs = ['bank_account'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-6">
            <label for="address" class="form-label">Alamat :</label>
            <textarea class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="address" id="address"
                      placeholder="Masukkan alamat Anda"><?php echo e(old('address', $submission->address)); ?></textarea>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>        
        <div class="col-md-6">
            <label for="application_letter" class="form-label">Surat Pengantar Proposal</label>
            <input class="form-control <?php $__errorArgs = ['application_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="application_letter" id="application_letter">
            <?php $__errorArgs = ['application_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->application_letter): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('public/storage/'.$submission->application_letter)); ?>" target="_blank"><?php echo e($submission->application_letter); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <label for="documentation" class="form-label">Dokumentasi foto Tempat Ibadah</label>
            <input class="form-control <?php $__errorArgs = ['documentation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="documentation" id="documentation">
            <?php $__errorArgs = ['documentation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->documentation): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('path/ke/file/'.$submission->documentation)); ?>" target="_blank"><?php echo e($submission->documentation); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <label for="tanah" class="form-label">Akta Tanah</label>
            <input class="form-control <?php $__errorArgs = ['tanah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="tanah" id="tanah">
            <?php $__errorArgs = ['tanah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->tanah): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('path/ke/file/'.$submission->tanah)); ?>" target="_blank"><?php echo e($submission->tanah); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <label for="rab" class="form-label">List Barang Keperluan</label>
            <input class="form-control <?php $__errorArgs = ['rab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="rab" id="rab">
            <?php $__errorArgs = ['rab'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->rab): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('path/ke/file/'.$submission->rab)); ?>" target="_blank"><?php echo e($submission->rab); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <label for="land_certificate" class="form-label">DSK kepengurusan</label>
            <input class="form-control <?php $__errorArgs = ['land_certificade'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="land_certificate" id="land_certificate">
            <?php $__errorArgs = ['land_certificate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->land_certificade): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('path/ke/file/'.$submission->land_certificate)); ?>" target="_blank"><?php echo e($submission->land_certificade); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <label for="management_letter" class="form-label">SKT</label>
            <input class="form-control <?php $__errorArgs = ['management_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="management_letter" id="management_letter">
            <?php $__errorArgs = ['management_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->management_letter): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('path/ke/file/'.$submission->management_letter)); ?>" target="_blank"><?php echo e($submission->management_letter); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <label for="npwp" class="form-label">NPWP Perwakilan</label>
            <input class="form-control <?php $__errorArgs = ['npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="npwp" id="npwp">
            <?php $__errorArgs = ['npwp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->npwp): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('path/ke/file/'.$submission->npwp)); ?>" target="_blank"><?php echo e($submission->npwp); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>
        <div class="col-md-6">
            <label for="domicile_letter" class="form-label">Surat domisili</label>
            <input class="form-control <?php $__errorArgs = ['domicile_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file"
                name="domicile_letter" id="domicile_letter">
            <?php $__errorArgs = ['domicile_letter'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
            <?php if($submission->domicile_letter): ?>
                <p class="mt-2">File Saat Ini: <a href="<?php echo e(asset('path/ke/file/'.$submission->domicile_letter)); ?>" target="_blank"><?php echo e($submission->domicile_letter); ?></a></p>
            <?php else: ?>
                <p class="mt-2">Tidak ada file terlampir.</p>
            <?php endif; ?>
        </div>

        <div class="col">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\submission-app\resources\views/admin/edit.blade.php ENDPATH**/ ?>