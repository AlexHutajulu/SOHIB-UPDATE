<div class="table-responsive">
    <table id="datatablesSimple" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>NIK</th>
                <th>Nama</th>
                <th>No Telepon</th>
                <th>Email</th>
                <th>Ibadah</th>
                <th>Lihat File</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($submission->nik); ?></td>
                    <td><?php echo e($submission->name); ?></td>
                    <td><?php echo e($submission->phone); ?></td>
                    <td><?php echo e($submission->email); ?></td>
                    <td><?php echo e($submission->ibadah); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.file', $submission->id)); ?>">
                            <i class="fa-regular fa-eye fa-lg" style="color: #005eff; margin-right: 10px;"></i>
                        </a>
                    <td><?php echo e($submission->status ?? 'NULL'); ?></td>
                    <td class="table-actions">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php /**PATH C:\xampp\htdocs\submission-app\resources\views/admin/submission-table.blade.php ENDPATH**/ ?>