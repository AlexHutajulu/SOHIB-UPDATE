

<?php $__env->startSection('title', 'SOHIB | Sistem Online Hibah Banjarbaru'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mt-4"></h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active"></li>
    </ol>

    
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $newSubmissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title"><?php echo e($submission->nik); ?></h3>
                        <h5 class="card-title"><?php echo e($submission->name); ?></h5>
                        <form action="<?php echo e(route('admin.approve', $submission->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="disetujui" value="disetujui">
                                <label class="form-check-label" for="disetujui">Disetujui</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="status" id="ditolak" value="ditolak">
                                <label class="form-check-label" for="ditolak">Tidak Disetujui</label>
                            </div>
                            <div class="col-md-12">
                                <label for="note" class="form-label">Catatan :</label>
                                <textarea class="form-control" name="note" id="note" rows="3"><?php echo e(old('note')); ?></textarea>
                                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <button type="submit" class="btn btn-primary my-3">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-md-12">
                <p>No new submissions.</p>
            </div>
        <?php endif; ?>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Data Pengajuan Masyarakat
        </div>
        <div class="card-body">
            <ul class="nav nav-tabs" id="myTabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="proses-tab" data-bs-toggle="tab" href="#proses" role="tab" aria-controls="proses" aria-selected="true">Proses</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="disetujui-tab" data-bs-toggle="tab" href="#disetujui" role="tab" aria-controls="disetujui" aria-selected="false">Disetujui</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="ditolak-tab" data-bs-toggle="tab" href="#ditolak" role="tab" aria-controls="ditolak" aria-selected="false">Ditolak</a>
                </li>
            </ul>
            <div class="tab-content mt-2" id="myTabsContent">
                <div class="tab-pane fade show active" id="proses" role="tabpanel" aria-labelledby="proses-tab">
                    <?php echo $__env->make('admin.submission-table', ['submissions' => $newSubmissions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="disetujui" role="tabpanel" aria-labelledby="disetujui-tab">
                    <?php echo $__env->make('admin.submission-table', ['submissions' => $approvedSubmissions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="tab-pane fade" id="ditolak" role="tabpanel" aria-labelledby="ditolak-tab">
                    <?php echo $__env->make('admin.submission-table', ['submissions' => $rejectedSubmissions], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\submission-app\resources\views/admin/new.blade.php ENDPATH**/ ?>