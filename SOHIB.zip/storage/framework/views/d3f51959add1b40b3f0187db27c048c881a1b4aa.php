
<?php /**PATH C:\xampp\htdocs\submission-app\resources\views/welcome.blade.php ENDPATH**/ ?>