<div class="table-responsive">
    <table id="datatablesSimple" class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>NIK</th>
                <th>Nama</th>
                <th>No Telepon</th>
                <th>Email</th>
                <th>Ibadah</th>
                <th>Lihat File</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($submissions as $submission)
                <tr>
                    <td>{{ $submission->nik }}</td>
                    <td>{{ $submission->name }}</td>
                    <td>{{ $submission->phone }}</td>
                    <td>{{ $submission->email }}</td>
                    <td>{{ $submission->ibadah }}</td>
                    <td>
                        <a href="{{ route('admin.file', $submission->id) }}">
                            <i class="fa-regular fa-eye fa-lg" style="color: #005eff; margin-right: 10px;"></i>
                        </a>
                    <td>{{ $submission->status ?? 'NULL' }}</td>
                    <td class="table-actions">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah anda yakin?')">Hapus</button>
                        </form>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
</div>

