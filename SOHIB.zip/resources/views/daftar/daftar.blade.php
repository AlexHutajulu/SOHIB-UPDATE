<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Akun</title>
    <link rel="stylesheet" href="{{ asset('css/login.css') }}">
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <a href="/">
                <img src="{{ asset('image/Banjarbaru.png') }}" alt="Logo" class="logo">
            </a>
            <p class="logo-text">SOHIB BANJARBARU</p>
        </div>
        <form action="{{ route('daftar.post') }}" method="POST" class="form-container">
            @csrf
            @if (Session('error'))
                <div class="alert alert-danger">
                    {{ Session('error') }}
                </div>
            @endif
            <h2 class="form-title">Daftar Akun</h2>
            
            <!-- NIK -->
            <div class="form-group">
                <label for="nik">NIK:</label>
                <input type="text" id="nik" name="nik" placeholder="Masukkan NIK Anda" required>
                @error('nik')
                    <div class="alert alert-danger">{{ $message }}</div>
                @enderror
            </div>
            
            <!-- Nama Lengkap -->
            <div class="form-group">
                <label for="name">Nama Lengkap:</label>
                <input type="text" id="name" name="name" placeholder="Masukkan Nama Lengkap Anda" required>
                @error('name')
                    <div class="alert alert-danger">{{ $message }}</div>
                @enderror
            </div>

            <!-- Email -->
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" placeholder="Masukkan Email Anda" required>
                @error('email')
                    <div class="alert alert-danger">{{ $message }}</div>
                @enderror
            </div>

            <!-- Password -->
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" placeholder="Masukkan Password Anda" required>
                @error('password')
                    <div class="alert alert-danger">{{ $message }}</div>
                @enderror
            </div>

            <div class="form-group">
                <button type="submit">Daftar</button>
            </div>
        </form>
    </div>
</body>
</html>
