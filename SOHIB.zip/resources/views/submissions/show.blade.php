@extends('layouts.masyarakat')

@section('title', 'Submissions')

@section('content')

@endsection
