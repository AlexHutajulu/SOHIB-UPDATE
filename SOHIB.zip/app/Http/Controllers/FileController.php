<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Submission;

class FileController extends Controller
{
    public function show($id, $type)
    {
        $submission = Submission::findOrFail($id);

        // Tentukan nama kolom file berdasarkan tipe yang diinginkan
        $column = $this->getColumnNameByType($type);

        // Dapatkan URL file dari kolom yang ditentukan
        $fileUrl = $submission->{$column};
        

        return redirect($fileUrl);
    }

    private function getColumnNameByType($type)
    {
        // Tentukan nama kolom berdasarkan tipe yang diinginkan
        $columns = [
            'application_letter' => 'application_letter',
            'documentation' => 'documentation',
            'tanah' => 'tanah',
            'rab' => 'rab',
            'land_certificate' => 'land_certificate',
            'management_letter' => 'management_letter',
            'notaris' => 'notaris',
            'npwp' => 'npwp',
            'domicile_letter' => 'domicile_letter',
            // ... tambahkan tipe file lainnya sesuai kebutuhan
        ];

        return $columns[$type];
    }

    public function showfile($id, $type)
    {
        $submission = Submission::findOrFail($id);

        // Tentukan nama kolom file berdasarkan tipe yang diinginkan
        $column = $this->file($type);

        // Dapatkan URL file dari kolom yang ditentukan
        $fileUrl = $submission->{$column};

        return redirect($fileUrl);
    }

    private function file($type)
    {
        // Tentukan nama kolom berdasarkan tipe yang diinginkan
        $columns = [
            'application_letter' => 'application_letter',
            'documentation' => 'documentation',
            'tanah' => 'tanah',
            'rab' => 'rab',
            'land_certificate' => 'land_certificate',
            'management_letter' => 'management_letter',
            'notaris' => 'notaris',
            'npwp' => 'npwp',
            'domicile_letter' => 'domicile_letter',
            // ... tambahkan tipe file lainnya sesuai kebutuhan
        ];

        return $columns[$type];
    }
}
