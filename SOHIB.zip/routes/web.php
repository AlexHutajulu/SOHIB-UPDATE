<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\SubmissionController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\FileController;
use App\Http\Controllers\MasyarakatController;

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('/landing');
});

Route::get('/landing', [LandingController::class, 'showLandingPage'])->name('landing');
Route::resource('submissions', SubmissionController::class);


//login
Route::get('/login',[LoginController::class,'login'])->name('login');
Route::post('/postlogin',[LoginController::class,'postlogin'])->name('postlogin');
Route::post('/masyarakatlogin',[LoginController::class,'masyarakatlogin'])->name('masyarakatlogin');
//logout
Route::post('/logout',[LoginController::class,'logout'])->name('logout');
//daftar
Route::get('/daftar', function () {
    return view('daftar.daftar');
});
Route::post('/login', [LoginController::class, 'daftar'])->name('daftar.post');

//admin
Route::get('/admin/new', [AdminController::class, 'newSubmissions'])->name('admin.new');
Route::post('/admin/approve/{id}', [AdminController::class, 'approveSubmission'])->name('admin.approve');
Route::get('/admin', [AdminController::class, 'index'])->name('admin.index');
Route::get('/admin/{id}', [AdminController::class, 'show'])->name('admin.show');
Route::get('/submisions', [SubmissionController::class,'submisions'])->name('submisions.create');
Route::get('/admin/file/{id}', [AdminController::class, 'file'])->name('admin.file');



Route::get('/submissions', [SubmissionController::class, 'index'])->name('submissions.index');
Route::get('/submissions/profil/{id}', [SubmissionController::class, 'profil'])->name('submissions.profil');

// Tambahkan route untuk edit
Route::delete('/admin/destroy/{id}', [AdminController::class, 'destroy'])->name('admin.destroy');
Route::get('/admin/edit/{id}', [AdminController::class, 'edit'])->name('admin.edit');
Route::put('/admin/update/{id}', [AdminController::class, 'update'])->name('admin.update');

//file 
Route::get('/file/{id}/{type}', [FileController::class, 'show'])->name('file.show');
Route::get('/submissions/file/{id}', [MasyarakatController::class, 'file'])->name('submissions.file');
Route::get('/submissions/show-file/{id}/{type}', [SubmissionController::class, 'showFile'])->name('submissions.show_file');